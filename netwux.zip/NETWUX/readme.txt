How to use NETWUX?

Easy, first of all, if you want to use the NetwUx network in every folders, no matter what path you are in, 
just move or copy the file netwux.web inside /usr/local/bin, then just write netwux.web to access our web.

>	sudo cp netwux.web /usr/local/bin

Then the rest is easy, just follow instructions when you open netwux.web!

More functions and pages soon, and please, to make this project work well, make some pages to share :)
